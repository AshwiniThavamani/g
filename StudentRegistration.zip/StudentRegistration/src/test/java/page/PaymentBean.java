package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PaymentBean {

	WebDriver driver;
	@FindBy(name="cname")
	private WebElement holderName;
	
	@FindBy(name="dcno")
	private WebElement cardNo;
	
	@FindBy(name="cvv")
	private WebElement cvvNo;
	
	@FindBy(name="exdate")
	private WebElement ExDate;
	

	@FindBy(id="btn")
	private WebElement Button;


	public PaymentBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void setSubmitLogin() {
		
		Button.submit();
	}
	public void setholderName(String hname) {

		holderName.sendKeys(hname);
	}
	
	public void setcardNo(String cno) {

		cardNo.sendKeys(cno);
	}
	
	public void setcvvNo(String cvvno) {

		cvvNo.sendKeys(cvvno);
	}
	
	public void setExDate(String exdate) {

		ExDate.sendKeys(exdate);
	}

	public void PaymentSuccess(String hname,String cno,String cvvno,String exdate) 
	{
		this.setholderName(hname);
		this.setcardNo(cno);
		this.setcvvNo(cvvno);
		this.setExDate(exdate);
		this.setSubmitLogin();
	}
	
}

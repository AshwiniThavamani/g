package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class StudentBean {
	
	WebDriver driver;
	@FindBy(name="fname")
	private WebElement FirstName;
	
	@FindBy(name="lname")
	private WebElement LastName;
	
	@FindBy(name="address")
	private WebElement Address;
	
	@FindBy(name="city")
	private WebElement City;
	@FindBy(name="state")
	private WebElement State;
	@FindBy(name="gender")
	private WebElement Gender;
	
	@FindBy(name="mobile")
	private WebElement Mobile;
	
	@FindBy(id="btn")
	private WebElement Button;
	
	@FindBy(xpath="/html/body/h1")
	private WebElement pageheading;
	
public StudentBean(WebDriver driver) {
	this.driver=driver;
	PageFactory.initElements(driver, this);
}

public String getPageTitle() {
	return pageheading.getText();
}

public void setSubmitLogin() {
	
	Button.submit();
}
public void setFirstName(String firstName) {

	FirstName.sendKeys(firstName);
}

public void setLastName(String lastName) {
	
	LastName.sendKeys(lastName);
}

public void setAddress(String address) {
	
	Address.sendKeys(address);
}

public void setCity(String city) {

	City.sendKeys(city);
}

public void setState(String state) {
	
	State.sendKeys(state);
}

public void setGender(String gender) {
	Gender=driver.findElement(By.id(gender));
	Gender.click();

}
public void setMobile(String mobile) {
	
	Mobile.sendKeys(mobile);
}

public void loginTo_NextPage(String firstName,String lastName,String address,String city,String state,String gender,String mobile)
		 {
	this.setFirstName(firstName);
	this.setLastName(lastName);
	this.setAddress(address);
	this.setCity(city);
	this.setState(state);
	this.setGender(gender);
	this.setMobile(mobile);
	this.setSubmitLogin();
}

}

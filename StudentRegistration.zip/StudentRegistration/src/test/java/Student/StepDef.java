package Student;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import page.PaymentBean;
import page.StudentBean;

public class StepDef {

	private WebDriver driver;
	private StudentBean studentBean;
	private PaymentBean paymentBean;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
	
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		studentBean=new StudentBean(driver);
		paymentBean=new PaymentBean(driver);
	}
	
	@Given("^Student Details$")
	public void student_Details() throws Throwable {
		driver.get("http://localhost:8084/StudentRegistration/");
	}

	@When("^valid Details$")
	public void valid_Details() throws Throwable {
      String pageHeading=studentBean.getPageTitle();
		
		assertTrue(pageHeading.equals("Student Registration Form"));
		studentBean.loginTo_NextPage("Ashwini", "Thavamani", "Bharathi Nagar", "Chennai", "Tamil Nadu", "female", "1212121212");

	}

	@Then("^Navigate to next Page$")
	public void navigate_to_next_Page() throws Throwable {
	  
		driver.switchTo().alert().accept();
		String url=driver.getCurrentUrl();
		System.out.println(url);
		assertTrue(url.equals("http://localhost:8084/StudentRegistration/PersonalDetails"));
	}

	
	@Given("^Payment Page$")
	public void payment_Page() throws Throwable {
		/*String url=driver.getCurrentUrl();
		System.out.println(url);
		assertTrue(url.equals("http://localhost:8084/StudentRegistration/PersonalDetails"));*/
		driver.get("http://localhost:8084/StudentRegistration/PersonalDetails");
	
	}

	@When("^Valid pay details$")
	public void valid_pay_details() throws Throwable {
		 String pageHeading=studentBean.getPageTitle();
			
			assertTrue(pageHeading.equals("Student Registration Form"));
			paymentBean.PaymentSuccess("ASHWINI", "1234512345123456", "123", "12/12/2000");
	}

	@Then("^Registered Successfully$")
	public void registered_Successfully() throws Throwable {
	  
		driver.switchTo().alert().accept();
	}

	
	
	@After
	public void tearDown() {
	//	driver.close();
	}
	
}

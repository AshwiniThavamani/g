function validateForm() {
    var x = document.forms["PerDetail"]["fname"].value;
    var y = document.forms["PerDetail"]["lname"].value;
    var z=document.forms["PerDetail"]["mobile"].value;
    var ads=document.forms["PerDetail"]["address"].value;
    var gender=document.forms["PerDetail"]["gender"].value;
    var name1 = /^[A-Z][a-zA-Z]{2,}$/;
    var name3 = /^\d{10}$/;
    if (x != "") 
    {
    	 if (y != "") 
    	 {
    		 
    		 if (z != "")
    		 {
    			 if(ads!="")
    			 {
    		    	if(gender!="")
    			    {
    			  if(x.match(name1))
    			  {
    				  if(y.match(name1))
    				  {
    					  if(z.match(name3))
    					  {
    						alert("Student details successfully saved!!!!")
    						return true;
    						
    					  }
    					  else
    					  {
    						  alert("Mobile Number must be 10 digits"); return false; 
    					  }
    				  }
    				  else
    				  {
    			           alert("Last Name must contain 3 characters with 1st capital letter");return false;
    				  }
    		        	
    			  }
    			  else
    			  {
    				  alert("First Name must contain 3 characters with 1st capital letter");return false;
    			  }
    			 
    		 }
    			else
       		 {
       			  alert("Gender cant be empty");return false;
       		 }
       		 
       	 }
    		else
        		 {
        			  alert("Address cant be empty");return false;
        		 }
        		 
        	 }
    		 else
    		 {
    			  alert("Mobile Number must be filled out");return false;
    		 }
    		 
    	 }
    	 else
    	  {
    		alert("Last Name must be filled out");return false;
    	  } 
    	
    }
    else
    	{
    	 alert("First Name must be filled out");return false;
    	}
 
}




function validatePay() 
{
    var a = document.forms["PayDetail"]["cname"].value;
    var b=document.forms["PayDetail"]["dcno"].value;
    var c=document.forms["PayDetail"]["cvv"].value;
    var name4 = /^[A-Z]{2,}$/;
    var name5 = /^\d{16}$/;
    var name6 = /^\d{3}$/;
    if (!a == "") 
    {
    	 if (!b == "")
    	 {
    		 if (!c == "") 
    		 {
    			 if(a.match(name4))
    			 {
    				
    				 if(b.match(name5))
        			 {
        				 
    					 if(c.match(name6))
            			 {
    						 alert("Payment received successfully!!!!");
    						 return true;
            			 }
            			 else
            			 {
            				 alert("CVV must be 3 digits");return false;
            			 }
    					 
        			 }
        			 else
        			 {
        				 alert("Debit/credit must be 16 digits");return false;
        			 }
    			 }
    			 else
    			 {
    				 alert("Card Holder Name must contain 3 characters");return false; 
    			 }
    			 
    		 }
    		 else
    		 {
    			  alert("CVV Number must be filled out");return false; 
    		 }
    	 }
    	 else
    	{
    		 alert("Debit/credit Number must be filled out");return false; 
    	}
    }
    else
    { 
    	alert("Card Holder Name must be filled out");return false;
     }
   
 
}




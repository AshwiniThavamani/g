package email;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {

	
	@Given("^admin email address and list of customer email address$")
	public void admin_email_address_and_list_of_customer_email_address() throws Throwable {
	  
	}

	@When("^admin received mail from merchant$")
	public void admin_received_mail_from_merchant() throws Throwable {
	   
	}

	@Then("^admin forwards received mail to list of customer$")
	public void admin_forwards_received_mail_to_list_of_customer() throws Throwable {
	    
	}

	@Given("^admin and merchant email address$")
	public void admin_and_merchant_email_address() throws Throwable {
	 
	}

	@When("^merchant provides offer$")
	public void merchant_provides_offer() throws Throwable {
	
	}

	@Then("^merchant send mail to admin$")
	public void merchant_send_mail_to_admin() throws Throwable {
	   
	}

	@Given("^From and to email address$")
	public void from_and_to_email_address() throws Throwable {
	
	}

	@When("^email address checked in the tables$")
	public void email_address_checked_in_the_tables() throws Throwable {
	
	}

	@When("^the email address doesnot exist$")
	public void the_email_address_doesnot_exist() throws Throwable {
	
	}

	@Then("^error is generated as email address is not exist$")
	public void error_is_generated_as_email_address_is_not_exist() throws Throwable {
	  
	}


	
}

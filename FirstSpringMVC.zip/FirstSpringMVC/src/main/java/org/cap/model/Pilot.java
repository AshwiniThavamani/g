package org.cap.model;


import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

@Entity
public class Pilot {

   @Id
   @GeneratedValue
   private int pilotId;
   @NotEmpty(message="*please enter first name")
   private String firstName;
   @NotEmpty(message="*please enter last name")
   private String lastName;
   @NotNull(message="*please enter date")
   @Past(message="*please enter past date")
   private Date dateOfBirth;
   @NotNull(message="*please enter date")
   @Future(message="*please enter future date")
   private Date dateOfJoining;
   @Email(message="*plase enter valid email")
   private String email;
   private Boolean isCertified;
   @Range(min=10000,max=200000,message="salary message should be within range")
   private double salary;
   

public Pilot() {
	
}


public int getPilotId() {
	return pilotId;
}


public void setPilotId(int pilotId) {
	this.pilotId = pilotId;
}


public String getFirstName() {
	return firstName;
}


public void setFirstName(String firstName) {
	this.firstName = firstName;
}


public String getLastName() {
	return lastName;
}


public void setLastName(String lastName) {
	this.lastName = lastName;
}


public Date getDateOfBirth() {
	return dateOfBirth;
}


public void setDateOfBirth(Date dateOfBirth) {
	this.dateOfBirth = dateOfBirth;
}


public Date getDateOfJoining() {
	return dateOfJoining;
}


public void setDateOfJoining(Date dateOfJoining) {
	this.dateOfJoining = dateOfJoining;
}


public Boolean getIsCertified() {
	return isCertified;
}


public void setIsCertified(Boolean isCertified) {
	this.isCertified = isCertified;
}


public double getSalary() {
	return salary;
}


public void setSalary(double salary) {
	this.salary = salary;
}


public String getEmail() {
	return email;
}


public void setEmail(String email) {
	this.email = email;
}


@Override
public String toString() {
	return "Pilot [pilotId=" + pilotId + ", firstName=" + firstName + ", lastName=" + lastName + ", dateOfBirth="
			+ dateOfBirth + ", dateOfJoining=" + dateOfJoining + ", email=" + email + ", isCertified=" + isCertified
			+ ", salary=" + salary + "]";
}


public Pilot(int pilotId, String firstName, String lastName, Date dateOfBirth, Date dateOfJoining, String email,
		Boolean isCertified, double salary) {
	super();
	this.pilotId = pilotId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.dateOfBirth = dateOfBirth;
	this.dateOfJoining = dateOfJoining;
	this.email = email;
	this.isCertified = isCertified;
	this.salary = salary;
}
	
}

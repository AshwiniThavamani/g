package org.cap.controller;

import java.util.List;

import javax.validation.Valid;

import org.cap.model.Pilot;
import org.cap.service.IPilotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {

	
	@Autowired
	private IPilotService service;
	private Pilot pilot;
	@RequestMapping("/hello")
	public ModelAndView sayHello() {
		String message="Hello World";
		return new ModelAndView("hellopage","msg",message) ;
	}
	
	@RequestMapping("/validateLogin")
	public String ValidateLogin(ModelMap map,@RequestParam("userName") String userName, @RequestParam("userPwd") String userPwd)
	{
		if(userName.equals("Ash")&&userPwd.equals("Ash123"))
		{
			List<Pilot> pilots=service.getAll();
			map.put("pilots", pilots);
			map.put("ipilot", new Pilot());
		   return "pilotForm";
		 }
		return "redirect:/";
		
	}
	
	@RequestMapping("/pilotForm")
	public String getPilotForm(ModelMap map) {
		List<Pilot> pilots= service.getAll();
		map.put("pilots", pilots);
		if(pilot!=null) {
		map.put("ipilot",pilot);
		}else {
		map.put("ipilot", new Pilot());
		}
		return "pilotForm";
	}
	
	@PostMapping("/savePilot")
	public String showPilotDetails(@Valid@ModelAttribute("ipilot") Pilot pilot1,BindingResult result) 
	{
		if(!result.hasErrors()) {
			//service.save(pilot);
				service.update(pilot1);
				System.out.println(pilot1);
			  pilot1=null;
			
		}
		
		return "redirect:pilotForm";
	}

	@GetMapping("/delete/{pilotId}")
	public String deletePilot(@PathVariable("pilotId") Integer pilotId) {
		service.delete(pilotId);
		
		return "redirect:/pilotForm";
	}
	
	
	@RequestMapping("/update/{pilotId}")
	public String updatePilot(@PathVariable("pilotId") Integer pilotId) {
		pilot=service.findPilot(pilotId);
		
		return "redirect:/pilotForm";
		
	}
	
	
}

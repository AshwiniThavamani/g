package org.cap.service;

import java.util.List;

import org.cap.dao.IPilotDao;

import org.cap.model.Pilot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("service")
public class PilotService implements IPilotService{
	
	@Autowired
	private IPilotDao pilotDao;

	@Override
	public void save(Pilot pilot) {
		
		pilotDao.save(pilot);
	}

	public List<Pilot> getAll() {
		// TODO Auto-generated method stub
		return pilotDao.getAll();
	}

	@Override
	public void delete(Integer pilotId) {
		// TODO Auto-generated method stub
		pilotDao.delete(pilotId);
	}

	@Override
	public void update(Pilot pilot1) {
		// TODO Auto-generated method stub
		pilotDao.update(pilot1);
	}

	@Override
	public Pilot findPilot(Integer pilotId) {
		// TODO Auto-generated method stub
		return pilotDao.findPilot(pilotId);
	}

}

package org.cap.dao;

import java.util.List;

import org.cap.model.Pilot;

public interface IPilotDao {

public	void save(Pilot pilot);
public List<Pilot> getAll();
void delete(Integer pilotId);
public void update(Pilot pilot1);
public Pilot findPilot(Integer pilotId);

}
